#include "calculator.h"

//function implementations
double add(double a, double b) {
    return a + b;
}

double mult(double a, double b) {
    return a * b;
}

double sub(double a, double b) {
    return a - b;
}

double division(double a, double b) {
    if (b != 0) {
        return a / b;
    } else {
        return 0; //division by zero
    }
}
