#include <stdio.h>
#include <winsock2.h>
#include "calculator.h"

#define DEFAULT_PORT 12345
#define MAX_CLIENTS 5

int main() {
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        fprintf(stderr, "WSAStartup failed.\n");
        return 1;
    }

    // create a socket for the server
    SOCKET serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket == INVALID_SOCKET) {
        fprintf(stderr, "Socket creation failed.\n");
        WSACleanup();
        return 1;
    }

    // set up server address structure
    struct sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    serverAddr.sin_port = htons(DEFAULT_PORT);

    // bind the socket to the server address
    if (bind(serverSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {

        fprintf(stderr, "Bind failed.\n");
        closesocket(serverSocket);
        WSACleanup();
        return 1;
    }

    // listen for incoming connections
    if (listen(serverSocket, MAX_CLIENTS) == SOCKET_ERROR) {

        fprintf(stderr, "Listen failed.\n");
        closesocket(serverSocket);
        WSACleanup();
        return 1;
    }

    printf("Server is listening on port %d...\n", DEFAULT_PORT);

    while (1) {
        // accept a connection from a client
        SOCKET clientSocket = accept(serverSocket, NULL, NULL);
        if (clientSocket == INVALID_SOCKET) {

            fprintf(stderr, "Accept failed.\n");
            closesocket(serverSocket);
            WSACleanup();
            return 1;
        }

        printf("Connection established with client.\n");

        char operation;
        double num1, num2, result;

        do {
            // read operation and operands from the client
            int bytesReceived = recv(clientSocket, (char*)&operation, sizeof(char), 0);

            if (bytesReceived == 0) {
                // Connection closed by the client
                printf("Connection closed by the client.\n");
                break;
            } else if (bytesReceived == SOCKET_ERROR) {
                // Error in receiving data
                fprintf(stderr, "Error in receiving data from client.\n");
                closesocket(clientSocket);
                break;
            }

            if (operation == '=') {
                break; // exit the loop if '=' is received
            }

            bytesReceived = recv(clientSocket, (char*)&num1, sizeof(double), 0);
            if (bytesReceived != sizeof(double)) {
                fprintf(stderr, "Error in receiving num1 from client.\n");
                closesocket(clientSocket);
                break;
            }

            bytesReceived = recv(clientSocket, (char*)&num2, sizeof(double), 0);
            if (bytesReceived != sizeof(double)) {
                fprintf(stderr, "Error in receiving num2 from client.\n");
                closesocket(clientSocket);
                break;
            }

            // perform calculation based on the operation
            switch (operation) {
                case '+':
                    result = add(num1, num2);
                    break;
                case '*':
                    result = mult(num1, num2);
                    break;
                case '-':
                    result = sub(num1, num2);
                    break;
                case '/':
                    result = division(num1, num2);
                    break;
                default:
                    result = 0; // invalid operation
                    break;
            }

            // send the result back to the client
            send(clientSocket, (char*)&result, sizeof(double), 0);

            // print the result on the server
            printf("Result: %.2lf\n", result);

        } while (operation != '=');

        // close the client socket
        closesocket(clientSocket);
    }

    // close the server socket
    closesocket(serverSocket);
    WSACleanup();

    return 0;
}
