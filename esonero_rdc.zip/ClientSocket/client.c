#include <stdio.h>
#include <winsock2.h>
#include "calculator.h"

#define DEFAULT_IP "127.0.0.1"
#define DEFAULT_PORT 12345

int main() {
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        fprintf(stderr, "WSAStartup failed.\n");
        return 1;
    }

    //create a socket for the client
    SOCKET clientSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (clientSocket == INVALID_SOCKET) {
        fprintf(stderr, "Socket creation failed.\n");
        WSACleanup();
        return 1;
    }

    //set up server address structure
    struct sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = inet_addr(DEFAULT_IP);
    serverAddr.sin_port = htons(DEFAULT_PORT);

    //connect to the server
    if (connect(clientSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
        fprintf(stderr, "Connection failed.\n");
        closesocket(clientSocket);
        WSACleanup();
        return 1;
    }

    printf("Connection established with the server.\n");

    char operation;
    double num1, num2, result;

    do {
        //get user input for operation or exit
        printf("\nEnter operation (+, *, -, /) or '=' to exit: ");
        if (scanf(" %c", &operation) != 1 || (operation != '+' && operation != '*' && operation != '-' && operation != '/' && operation != '=')) {

            printf("You entered an invalid operator.\n");

            //clear input buffer to avoid infinite loop
            while (getchar() != '\n');
            continue;
        }

        if (operation == '=') {
            break;
        }

        //get user input for two doubles
        printf("Enter two doubles: ");
        if (scanf("%lf %lf", &num1, &num2) != 2) {

            printf("You entered an invalid input for numbers.\n");

            //clear input buffer to avoid infinite loop
            while (getchar() != '\n');
            continue;
        }

        //send operation and operands to the server
        send(clientSocket, (char*)&operation, sizeof(char), 0);
        send(clientSocket, (char*)&num1, sizeof(double), 0);
        send(clientSocket, (char*)&num2, sizeof(double), 0);

        //receive and display the result from the server
        recv(clientSocket, (char*)&result, sizeof(double), 0);
        printf("Result: %.2lf\n", result);

    } while (operation != '=');

    //close the client socket
    closesocket(clientSocket);
    WSACleanup();

    return 0;
}
